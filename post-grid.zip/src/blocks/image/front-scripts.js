
document.addEventListener("DOMContentLoaded", function (event) {
    var PGBlockPostGrid = document.querySelectorAll('.PGBlockPostGrid');
    if (PGBlockPostGrid != null) {

    }







});

