document.addEventListener("DOMContentLoaded", function (event) {
	var PGBlockMasonryWrap = document.querySelectorAll(".PGBlockMasonryWrap");

	if (PGBlockMasonryWrap != null) {
		PGBlockMasonryWrap.forEach((item) => {
			var masonryArgs = item.getAttribute("data-masonry");

			var masonryArgsObj = JSON.parse(masonryArgs);

			var blockId = masonryArgsObj.blockId;
			var masonryOptions = masonryArgsObj.masonryOptions;

			console.log(masonryOptions);
			console.log(blockId);

			var elemX = document.getElementById(blockId);

			console.log(elemX);
			if (elemX != null) {
				var msnry = new Masonry(
					elemX,
					{
						itemSelector: masonryOptions.itemSelector,
						gutter: 20,
						percentPosition: true
					}
				);

			}
		});
	}
});

