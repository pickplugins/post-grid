=== Post Grid Combo ===
	Contributors: PickPlugins
	Donate link: https://www.pickplugins.com/post-grid
	Tags: post grid, grid, custom post grid, post type grid, grid display, category filter, custom post, filter, filtering, grid, layout, list, masonry, post, post filter, post layout, taxonomy, taxonomy filter,
	Requires at least: 3.8
	Tested up to: 6.1.1
	Stable tag: 2.2.24
	License: GPLv2 or later
	License URI: http://www.gnu.org/licenses/gpl-2.0.html

	Post Grid Combo is extremely easy to use for creating grid-layout and post-layout. Also, we're offering many small blocks with extensive flexibility.


== Description ==

Post Grid Combo is the #1 Gutenberg Blocks plugin for creating a fully customizable "grid layout", "post layout" and "Custom Post Grid". Not only are we offering a "post grid" block, but you'll also get many small blocks like - Post Grid Filterable, Post Title, Post Excerpt, Post Author, Post Taxonomies, Accordions, Tabs, and a lot more with extensive flexibility.


### Post Grid by  [http://pickplugins.com](http://pickplugins.com)

* [See the Live demo](https://getpostgrid.com/)
* [Buy Premium](https://www.pickplugins.com/post-grid/)
* [Documentation](https://getpostgrid.com/documentations/)
* [Support](https://www.pickplugins.com/support/)


#Grid Layouts
We have a bunch of premade Grid layouts available that will help you to create a grid with just one simple click. Also, you'll get full flexibility to customize that grid. Our N'th item CSS option will allow you to create a much more advanced grid layout. 
[Grid Layout Demo =>](https://getpostgrid.com/grid-layouts/)

#Post Layouts
We also have many premade post layouts that you can use. You can apply styles and add or remove any blocks(including our premade small blocks) to your layout to make it more impressive. 
[Post Layout Demo =>](https://getpostgrid.com/post-layouts/)

#Advance Query
We're providing the maximum level of query features that you could ever imagine. You can query posts by various post types, custom taxonomies, meta queries, date queries, author queries, and a lot more. 
 
#Pagination
Along with the Normal Pagination, we have included some other pagination styles like Ajax Pagination, Next-Previous Pagination, Load More, and Infinite Load. 











**Responsive Grid**
Post Grid is responsive and almost work in any device. good things is you can set some option based on mobile or tablet
device. like you can set custom column number on mobile device.

**Any Custom Post**
Post grid is master of displaying grid from any custom post types. You will never ever worried about. you can also
select multiple post types to display on single post grid.

**Taxonomy & Terms Support**
Query post by custom taxonomy and terms is the most wanted feature already in post grid, you can select multiple taxonomy and terms for query post.

**Unlimited Post Grid**
There is no limitation of creating post grid, you can create unlimited post grid on your website.

**Skin & Layout Based**
Post grid items based on skin and layout based, you can customize layout elements and change skin, if you have basic CSS
 knowledge you can customize layout elements and apply your own style.

**Pagination Support**
Post Grid has pagination support, thats mean if you post grid has many post so user can go through each pagination to
see your post archive. you can limit the pagination item count and "Next" & "Previous" text as well, you can also use
icons instead of text for these.

**Search Input Field**
you can display search input field at top of grid, so user can search though your grid and find their desired post.

**Post Query Features**
Post Grid has many support and input to display your desired post on the grid, you can customize

* Post types,
* Post categories, tags
* Taxonomies & terms, taxonomy relation, terms relation,
* Post publish status,
* Post order and
* Order by, order by meta field value,
* Custom number of posts per page, offset
* Exclude post by ids
* Include post by ids
* Display post grid based on keyword search.
* Grid item width, you can set custom width for grid item based on mobile, tablet and desktop device. you can also set % based column, like 30% will gives you 3 column in each row.
* Grid item height - you can set custom height of grid item, based on device you can set auto height, fixed height or max height.
* Grid item background color.
* Grid item padding.
* Grid item margins.
* Lazy load - you can enable lazy load to hide grid on page load.
* Featured image custom size selection.
* Custom media source - there is 3 different source available in free version. Featured Image, First images from content, Empty thumbnail
* Masonry style grid also available.



###Premium features

**View Type**

* Filterable
* Glossary
* Carousel Slider
* Collapsible

**Post grid for Archives**

* category.php
* tags.php
* search.php
* author.php
* Custom taxonomy & terms page

**Advance Pagination types**

* Ajax Pagination
* Next-Previous
* Filterable pagination
* Ajax Load More



**Advance Media Sources**

* First youtube video from content
* Custom youtube video
* First vimeo video from content
* Custom vimeo video
* First dailymotion video from content
* Custom dailymotion video
* First MP3 from content
* Custom MP3
* First SoundCloud from content
* Custom SoundCloud
* Custom Thumbnail
* Font Awesome
* Custom Video

**Filterable Features**

* Display navs by taxonomies & terms or Custom filters.
* Navs style - Font size, Font color, Background color, Margin, display post count.
* Navs view style -  Inline, Dropdown, Radio, Checkbox.
* Custom text for All navs.
* Custom default active filter
* Single or group filter navs.
* Sorting filter



**Advance Query**

* Meta query - Single field and multiple field query
* Extra query parameter - you can provide your own query parameter like `post__in=1,2,3&post__not_in=1,2,3`
* Permission parameters - Show posts if user has the appropriate capability
* Sticky post query - Include sticky post or Exclude sticky post
* Date parameters - by Exact date, Between two date.
* Author parameters - Include authors by ids, Exclude authors by ids.
* Password parameters - Display only password protected posts, Display only posts without passwords, Display only posts with and without passwords, Posts with particular password.


## 3rd party plugins support

**WooCommerce**
WooCommerce is #1 ecommerce plugin for WordPress and we provide full support to display following elements for products on the post grid.

Add to cart | Full price | Sale price | Regular price | Star rating | Text rating | Product categories | Product tags | Product gallery | Product SKU


**Easy Digital Download**
Easy Digital Download is another best ecommerce for digital products and we provide full support to display following elements for downloads on the post grid.

Price | Variable prices | Sales stats | Earnings stats | Add to cart | Text rating | download categories | download tags


**Advanced Custom Fields**
Advanced Custom Fields is #1 custom field's plugin for WordPress and we added full support to display following meta fields for any post types.

Text | Textarea | Number | Range | Email | URL | Password | Link | Post object | Page link | Taxonomy | User | Relationship | Image | File | Wysiwyg | oEmbed | Select | Checkbox | Radio | Button group | True / False | Date picker | Time picker | Datetime picker | Google Map


**CMB2**
CMB2 is another best custom field's plugin for WordPress and we added full support to display following meta fields for any post types.

Text | Email | URL | Money | Textarea | Select | Checkbox | Radio | Link | File | Wysiwyg | oEmbed

**Custom Field Suite**
Custom Field Suite is another best custom field's plugin for WordPress and we added full support to display following meta fields for any post types.

Text | Textarea | Link | Taxonomy | User | Relationship | File | Wysiwyg | Select | True / False | Date picker

**The Events Calendar**
The Events Calendar is #1 event's manager plugin for WordPress and we added full support to display following elements for event post type

Event categories | Event tags | Event start date | Event end date | Event URL | Event cost | Venue address | Venue city | Venue country | Venue province | Venue zip | Venue phone | Venue URL | Venue Map | Organizer Phone | Organizer Website | Organizer Email


**Events Manager**
Events Manager is another best event's manager plugin for WordPress and we added full support to display following elements for event post type

Event categories | Event tags | Event start date | Event end date | Event start time | Event end time | Event spaces | Max Spaces | Cut-Off Date | Cut-Off time



<strong>Video Tutorial(with premium version interface)</strong>

* [All tutorials](https://www.youtube.com/playlist?list=PL0QP7T2SN94bpTVghETSePuVvRROpuEW6)



== Installation ==

1. Install as regular WordPress plugin.<br />
2. Go your plugin setting via WordPress Dashboard and find "<strong>Post Grid</strong>" activate it.<br />

After activate plugin you will see "Post Grid" menu at left side on WordPress dashboard click "New Post Grid" and use the options field "Post Grid"<br />

<br />
<strong>How to use on page or post</strong><br />
When Post Grid options setup done please publish Post Grid as like post or page<br />

and then copy shortcode from top of <strong>Post Grid Options</strong> `[post_grid  id="1234" ]`<br />

then paste this shortcode anywhere in your page to display grid<br />







== Screenshots ==

1. screenshot-1
2. screenshot-2
3. screenshot-3
4. screenshot-4
5. screenshot-5
6. screenshot-6
7. screenshot-7
8. screenshot-8

== Changelog ==

	= 2.2.24 =
    * 2022-01-12 - fix - Debug text issue fixed.
    * 2022-01-14 - update - Styles component updated.

	= 2.2.23 =
    * 2022-01-12 - add - Style component added to post author field block.
    * 2022-01-12 - fix - Old layout element post excerpt css issue fixed.
    * 2022-01-12 - update - Color component update.
    * 2022-01-12 - update - Background Color component update.
    * 2022-01-12 - fix - Post Tags Block - CSS conflict between items and front-text.
    * 2022-01-12 - fix - Post-Taxonomies block An extra ‘seperator’ HTML markup was generated.
    * 2022-01-12 - fix - Post-Taxonomies block Style conflict between items and front-text.
    * 2022-01-12 - fix - Post Title Block – Typography section font family not changing and extra hello word found.
    * 2022-01-12 - fix - Breadcrumb Block Under Icon, color and background color isn’t working.
    * 2022-01-12 - fix - Breadcrumb Block Separator HTML markup issue.





	= 2.2.22 =
    * 2022-12-28 - fix - Post Title Block - Post title link to custom URL error fixed.

	= 2.2.21 =
    * 2022-12-28 - fix - Post Grid Block - Post types multi select issue fixed.
    * 2022-12-28 - fix - Post Grid Block - Orderby multi select issue fixed.
    * 2022-12-28 - fix - Post Grid Shortcode - Taxonomy terms first group keep expanded

	= 2.2.20 =
    * 2022-12-26 - fix - Old layout wrapper issue fixed.

	= 2.2.19 =
    * 2022-12-25 - add - added new block - Archive Title
    * 2022-12-25 - add - added new block - Archive Descriptions
    * 2022-12-25 - add - added new block - Post Comment Count
    * 2022-12-25 - fix - added more elements for breadcrumb block.
    * 2022-12-25 - fix - ol post layout - post title link css issue fixed.

	= 2.2.18 =
    * 2022-12-23 - fix - added more elements for breadcrumb block.

	= 2.2.17 =
    * 2022-12-22 - fix - Old layout style issue fixed.
    * 2022-12-22 - add - New block breadcrumb added.

	= 2.2.16 =
    * 2022-12-21 - fix - Post date icon issue fixed.
    * 2022-12-20 - fix - Old layout post title html supprot added.

	= 2.2.15 =
    * 2022-12-20 - add - New block social share added.
    * 2022-12-20 - fix - Post Grid Filterable - Multiilter issue fixed.
    * 2022-12-20 - fix -On 'Post Categories, Post Tags, Post taxonomies' block, the item color isn't generating both the front and back end.
    * 2022-12-20 - fix - On the feature image block & Image, default width:100% and height:auto isn't working on the first block initiate.
    * 2022-12-20 - fix - 'Post Date' block, icon issue fixed.
    * 2022-12-20 - fix - 'Post Title' block, font size breaking issue fixed.
    * 2022-12-20 - fix - 'post grid' block  loop item border or box-shadow empty breaking issue fixed.



	= 2.2.14 =
    * 2022-12-11 - add - New block shortcode added.

	= 2.2.13 =
    * 2022-12-11 - Fix - Post Grid Block - Post Query by author in, author not in, Tag in, tag and, tag not in, ta slug in, tag slug and, category and, category no in, category in, post parent in, post parent no in, post in, post not in, post name in
    * 2022-12-11 - Fix - Post Grid Block - Tutorials link updated
    * 2022-12-11 - Fix - Post Grid Filterable Block - Tutorials link updated
    * 2022-12-11 - Fix - Icon Block - New icon position before link and after link added.
    * 2022-12-11 - Fix - Post Grid Block - Typo issue fixed.





	= 2.2.12 =
    * 2022-12-10 - Add - Terms List Block added

	= 2.2.10 =
    * 2022-12-06 - fix - post grid blok - Loop item typography issue fixed.

	= 2.2.9 =
    * 2022-12-06 - fix - purchase link issue fixed.

	= 2.2.8 =
    * 2022-12-05 - fix - Warning: Invalid argument supplied for foreach() fixed

	= 2.2.7 =
    * 2022-12-03 - fix - PHP fatal error fixed for block categories.

	= 2.2.6 =
    * 2022-12-01 - fix - Old - Post Title link color issue fixed
    * 2022-12-01 - fix - Old - Container text align issue fixed.


	= 2.2.5 =
    * 2022-12-01 - fix - Post Grid Filterbale - Pagination issue fixed.
    * 2022-12-01 - fix - Post Grid Shortcode - default style missing issue fixed.


	= 2.2.4 =
    * 2022-12-01 - fix - Older Layout element css issue fixed.

	= 2.2.3 =
    * 2022-11-30 - fix - PHP fatal error fixed for block categories.

	= 2.2.2 =
    * 2022-11-30 - fix - Fatured image block - Fatured image default size issue fixed.
    * 2022-11-30 - fix - Image block - Fatured image default size issue fixed.
    * 2022-11-30 - fix - Post Grid Filterable - Post per page number issue fixed.
    * 2022-11-30 - fix - Post Grid Filterable - All navs issue fixed.

	= 2.2.1 =
    * 2022-11-30 - fix - PHP fatal error fixed for block categories.


	= 2.2.0 =
    * 2022-08-13 - update - Rebanding the plugin name "Post Grid" to "Post Grid Combo"
    * 2022-08-13 - add - Added sevral Gutenberg blocks
    * 2022-08-13 - add - "Post Title" block added. 
    * 2022-08-13 - add - "Post Excerpt" block added. 
    * 2022-08-13 - add - "Read More" block added. 
    * 2022-08-13 - add - "Advance Text" block added. 
    * 2022-11-17 - add - "Post Author" block added. 
    * 2022-11-17 - add - "Post Author Fields" block added. 
    * 2022-11-17 - add - "Featured Image" block added. 
    * 2022-11-17 - add - "Image" block added. 
    * 2022-11-17 - add - "Post Categories" block added. 
    * 2022-11-17 - add - "Post Tags" block added. 
    * 2022-11-17 - add - "Post Terms" block added. 
    * 2022-11-17 - add - "Post Date" block added. 
    * 2022-11-17 - add - "Read More" block added. 
    * 2022-11-17 - add - "Advance Text" block added. 
    * 2022-11-17 - add - "Post Grid" block added. 
    * 2022-11-17 - add - "List Items" block added. 
    * 2022-11-17 - add - "Icons" block added. 
    * 2022-11-17 - add - "Layers" block added. 
    * 2022-11-17 - add - "Accordion" block added. 
    * 2022-11-17 - add - "Tabs" block added. 
    * 2022-11-17 - add - "Post Grid - Filterable" block added. 



	= 2.1.24 =
    * 2022-07-24 - fix - Custom CSS character issue fixed.

	= 2.1.23 =
    * 2022-04-23 - fix - Custom scripts & CSS field issue fixed.


	= 2.1.22 =
    * 2022-04-07 - fix - Ajax search result filter by "Include by post ID" issue fixed.

	= 2.1.21 =
    * 2022-04-03 - fix - CSS escape issue fixed.



	= 2.1.20 =
    * 2022-03-16 - fix - More HTML string output for Search icon, loading icon, media html, no text found.



	= 2.1.19 =
    * 2022-03-16 - fix - HTML string output for category, tags, content, share button issue fixed.

	= 2.1.18 =
    * 2022-03-15 - fix - HTML string output issue fixed.


	= 2.1.17 =
    * 2022-03-08 - fix - More Escaping issue fixed.

	= 2.1.16 =
    * 2022-03-05 - fix - Escaping issue fixed.

	= 2.1.15 =
    * 2022-03-04 - fix - Fixed minor security issue.


	= 2.1.14 =
    * 2021-12-24 - add - Shortcdoe support for layout elements custom classes.

	= 2.1.13 =
    * 2021-12-15 - fix - SQL security issue fixed.

    = 2.1.12 =
    * 2021-12-09 fix -  PHP warning issue fixed.


    = 2.1.11 =
    * 2021-08-06 add - search method added ajax and on form submit. ajax method pagination may not work properly, use on form submit instead.

    = 2.1.10 =
    * 2021-07-31 add - featured image improved for responsive load.

    = 2.1.9 =
    * 2021-07-31 add - security on search result.
    * 2021-07-31 remove - remove ajax search result for fixing pagination issue.
    * 2021-07-31 add - added submit button on search form


    = 2.1.8 =
    * 2021-06-27 fix - escaping issue fixed.

    = 2.1.7 =
    * 2021-06-20 fix - column width % value issue fixed.

    = 2.1.6 =
    * 2021-06-19 add - column number added for grid


    = 2.1.5 =
    * 2021-05-05 fix - php error issue fixed for old layouts users.

    = 2.1.4 =
    * 2021-05-03 fix - escaping issue fixed.

	= 2.1.3 =
    * 2021-04-14 remove - unnecessary css library file removed
    * 2021-04-14 fix - security issue updated.

	= 2.1.2 =
    * 2021-04-13 fix - security issue updated.

	= 2.1.1 =
    * 2021-02-22 add - lazy load issue fixed.
    * 2021-02-22 add - lazy load image alt text added

	= 2.1.0 =
    * 2021-02-19 remove - remove old layout editor

	= 2.0.76 =
    * 2021-02-15 add - lazy load image alt text added


	= 2.0.75 =
    * 2021-01-23 add - taxonomy parameter for archive page for pro version integration.

	= 2.0.74 =
    * 2020-11-19 add - filter hook post_grid_link_to_args added
    * 2020-11-19 add - filter hook post_grid_author_link_to_args added

	= 2.0.73 =
    * 2020-09-17 fix - unnecessary function removed

	= 2.0.72 =
    * 2020-09-17 fix - security issue fixed.

	= 2.0.71 =
    * 2020-08-17 fix - post grid elements action hook order issue fixed.

	= 2.0.70 =
    * 2020-08-08 fix - layout editor lazy load issue fixed.

	= 2.0.69 =
    * 2020-07-05 fix - Layouts editor saving issue fixed.


	= 2.0.68 =
    * 2020-07-04 add - Layouts library added.

	= 2.0.67 =
    * 2020-06-16 remove - remove request popup for reviews.

	= 2.0.66 =
    * 2020-06-16 fix - undefined index issue fixed. functions.php line 85
    * 2020-06-16 fix - undefined function excerpt_remove_blocks issue fixed.
    * 2020-06-16 remove - remove popup for reviews.


	= 2.0.65 =
    * 2020-06-04 add - Ignore paged/page variable from query to display same posts on paginated page.

	= 2.0.64 =
    * 2020-06-04 fix - layout import skip added.

	= 2.0.63 =
    * 2020-06-03 fix - remove bootstrap from front-end

	= 2.0.62 =
    * 2020-06-03 fix - elements wrapper custom css class issue fixed.
    * 2020-06-03 add - Element added for "Site Reviews" plugin

	= 2.0.61 =
    * 2020-05-29 add - reviews request popup box added.
    * 2020-05-30 add - duplicate/clone post grid and post grid layout added.
    * 2020-05-30 add - addon "Loop ads" added

	= 2.0.60 =
    * 2020-05-24 add - addon "Search & Filter" added
    * 2020-05-24 add - addon "Post/Page Templates" added
    * 2020-05-29 add - import layouts notice added.


	= 2.0.59 =
    * 2020-05-21 add - Elements added for "WCK - Custom Fields and Custom Post Types Creator" plugin
    * 2020-05-21 add - Elements added for "WP Job Manager" plugin
    * 2020-05-21 add - Elements added for "Simple Job Board" plugin
    * 2020-05-21 add - Element "Categories" link target option added
    * 2020-05-21 add - Element "Tags" link target option added


	= 2.0.58 =
    * 2020-05-19 add - Element added for "Like Button Rating" plugin
    * 2020-05-19 add - Element added for "WP-PostViews" plugin
    * 2020-05-19 add - Element added for "Post Views Counter" plugin
    * 2020-05-19 add - Element added for "Page Views Count" plugin
    * 2020-05-19 add - Element added for "Page Visit Counter" plugin

	= 2.0.57 =
    * 2020-05-15 fix - masonry center align issue fixed.
    * 2020-05-15 add - media link target option added.
    * 2020-05-15 fix - rate-my-post missing issue fixed.

	= 2.0.56 =
    * 2020-05-15 fix - Excerpt element output issue fixed.

	= 2.0.55 =
    * 2020-05-4 fix - remove empty read more text to avoid conflict old layout.
    * 2020-05-15 add - Element added for "kk Star Ratings" plugin
    * 2020-05-15 add - Element added for "Multi Rating" plugin
    * 2020-05-15 add - Element added for "Rate my Post" plugin
    * 2020-05-15 add - Element added for "Rating-Widget" plugin
    * 2020-05-15 add - Element added for "WP-PostRatings" plugin
    * 2020-05-15 add - Elements visitor votes, overall rating added for "Yasr – Yet Another Stars Rating" plugin
    * 2020-05-15 add - Element added for "YITH - Add to Wishlist" plugin


	= 2.0.54 =
    * 2020-05-4 optimize - optimize layout element CSS generate
    * 2020-05-4 fix - grid item text align issue fixed.
    * 2020-05-4 fix - element author and author link issue fixed.


	= 2.0.53 =
    * 2020-05-04 fix - var_dump issue fixed for excerpt.
     * 2020-05-04 add - query post by ids added.


	= 2.0.52 =
    * 2020-05-01 fix - lazy load issue fixed.
    * 2020-05-04 fix - exclude by post ids issue fixed.
    * 2020-05-04 fix - layout css issue fixed.
    * 2020-05-04 add - prefix text for post date element
    * 2020-05-04 add - prefix text for post author element


	= 2.0.51 =
    * 2020-05-01 fix - pagination displaying issue fixed
    * 2020-05-01 add - action hook post_grid_pagination_{type} added


	= 2.0.50 =
    * 2020-04-30 fix - media link issue fixed.


	= 2.0.49 =
    * 2020-04-30 fix - post title link issue fixed.

	= 2.0.48 =
    * 2020-04-29 fix - new layout media image source issue fixed.
    * 2020-04-29 add - default layout xml file added and ready to import.
    * 2020-04-30 add - added new media source "SiteOrigin first image"


	= 2.0.47 =
    * 2020-04-29 add - No post found custom input field added
    * 2020-04-29 fix - Media height issue fixed.
    * 2020-04-29 fix - masonry issue fixed.


	= 2.0.46 =
    * 2020-04-21 update - Layout builder re-designed.
    * 2020-04-21 update - Remove unnecessary CSS and JS files.
    * 2020-04-21 update - Optimize CSS and JS file loading.


	= 2.0.45 =
    * 2020-04-14 remove - remove unnecessary scripts and css files.


	= 2.0.44 =
    * 2020-02-06 fix - tag links issue fixed.


	= 2.0.43 =
    * 17/11/2019 fix - exclude current post when post grid display on single post/custom post types

	= 2.0.42 =
    * 15/11/2019 fix - broken html issue when no post found

	= 2.0.41 =
    * 07/10/2019 fix - select2 js issue fixed

	= 2.0.40 =
    * 07/10/2019 removed - removed font-awesome-5 from front-end.
    * 07/10/2019 fix - post grid meta box style broken issue fixed.


	= 2.0.39 =
    * 22/08/2019 fix - Offset issue with pagination conflict issue fixed.

	= 2.0.38 =
    * 18/07/2019 update - Search input field loading icon changed.
    * 18/07/2019 update - Default layout element title replaced by title with linked and thumbnail linked with post url
    * 18/07/2019 update - Ajax taxonomies and terms loading on change post types.
    * 18/07/2019 update - Placeholder text added for some input fields.
    * 18/07/2019 update - Featured image size default "large" set and linked to post url

	= 2.0.37 =
    * 05/07/2019 fix - query_orderby array to string issue fix
    * 05/07/2019 fix - remove some unnecessary function.
    * 05/07/2019 fix - remove some unnecessary css from file.


	= 2.0.36 =
    * 22/06/2019 fix - select2 js script error issue fixed.


	= 2.0.35 =
    * 26/05/2019 fix - js script error issue fixed.
    * 26/05/2019 add - Some video tutorials added.

	= 2.0.34 =
    * 15/05/2019 fix - Custom CSS & JS saveing issue fixed
    * 15/05/2019 fix - select2 issue fixed

	= 2.0.33 =
    * 08/05/2019 add - terms relation AND added.
    * 08/05/2019 add - share buttons added in layout editor.
    * 08/05/2019 add - Horizontal line added in layout editor.


	= 2.0.32 =
    * 05/05/2019 remove - removed some unnecessary script and css files.



	= 2.0.31 =
    * 21/01/2019 update - update admin settings

	= 2.0.30 =
    * 21/01/2019 fix - Pagination bug fixed.

	= 2.0.29 =
    * 07/09/2018 remove - Removed masonry.js file form plugin used default WP jquery-masonry
    * 07/09/2018 update - Remove some js & css file loaded globaly, only loaded under post grid edit page.


	= 2.0.28 =
    * 18/08/2018 fix - pagination issue fixed.

	= 2.0.27 =
    * 24/05/2018 fix - Grid items responsive height issue fixed, set auto height for mobile and tablets
    * 24/05/2018 fix - Grid items media responsive height issue fixed, set auto height for mobile and tablets

	= 2.0.26 =
    * 21/03/2018 add - Post grid search for individual grid on same page
    * 21/03/2018 add - Press enter to reset search result.

	= 2.0.25 =
    * 15/02/2018 fix - Offset issue fixed.

	= 2.0.24 =
    * 12/02/2018 fix - Default search keyword fatching, added an option to disable.

	= 2.0.23 =
    * 31/01/2018 removed - Removed social share button on help page.


	= 2.0.22 =
    * 27/01/2018 fix - security issue fixed.

	= 2.0.21 =
    * 20/01/2017 add - Croatian  translation added.

	= 2.0.20 =
    * 13/01/2017 fix - translation issue fixed.

	= 2.0.19 =
    * 11/01/2017 add - added Bulgarian translation.

	= 2.0.18 =
    * 11/01/2017 fix - excerpt display issue.

	= 2.0.17 =
    * 31/12/2016 update - update font-awesome.

	= 2.0.16 =
    * 16/12/2016 fix - flip-y & flip-y skin mobile device issue fixed.

	= 2.0.15 =
    * 12/12/2016 add - Taxonomy query added.

	= 2.0.14 =
    * 03/12/2016 fix - Color Picker class issue fixed.

	= 2.0.13 =
    * 03/10/2016 fix - Fix some security issues.

	= 2.0.12 =
    * 03/10/2016 removed - Import Content Layouts removed for temporary.

	= 2.0.11 =
    * 24/08/2016 fix - php error issue fixed.

	= 2.0.10 =
    * 27/07/2016 add - Lazy Load.
    * 27/07/2016 add - Featured Image linked to post.
    * 27/07/2016 add - Grid Items Height.
    * 27/07/2016 add - Create New layout on Layout Editor.
    * 27/07/2016 add - Settigns - Export Content Layouts.
    * 27/07/2016 add - Settigns - Import Content Layouts.
    * 27/07/2016 add - Settigns - Remove Content Layouts.


	= 2.0.9 =
    * 24/06/2016 fix - minor php issue fixed.

	= 2.0.8 =
    * 14/06/2016 fix - owl.carousel conflict issue fixed.

	= 2.0.7 =
    * 23/04/2016 fix - social share button(Incrementing) issue fixed.

	= 2.0.6 =
    * 21/04/2016 add - display alt text for featured images.
    * 21/04/2016 add - display alt text for gallery images.
    * 21/04/2016 add - Export Content Layouts.
    * 21/04/2016 add - delete option for exported files.
    * 21/04/2016 add - translation added.


	= 2.0.5 =
    * 17/01/2016 - fix - read more link issue fixed.
    * 17/01/2016 - fix - empty content issue fixed.

	= 2.0.4 =
    * 13/01/2016 - add - layout overwrite issue fixed.

	= 2.0.3 =
    * 03/01/2016 - add - post tags linked.

	= 2.0.2 =
    * 11/12/2015 - fix - shortcode issue fixed.

	= 2.0.1 =
    * 25/11/2015 add - added two item for layout editor post with link and thumb with link.

	= 2.0.0 =
    * 21/10/2015 update - Recoded & Redesign plugin.

	= 1.9 =
	* 05/11/2015 setting UI update.

	= 1.8 =
	* 01/10/2015 add- added soem premium features.

	= 1.7 =
	* 13/05/2015 fix-  license issue fixed.

	= 1.6 =
	* 13/05/2015 add-  Custom CSS box.
	* 13/05/2015 edit- Improved Grid Builder.
	* 13/05/2015 add- hover animation for hover items.
	* 13/05/2015 add- display thumbnail via External Featured Image(meta key).

	= 1.5 =
	* 13/05/2015 fix-  flter content.
	* 13/05/2015 fix-  social icons hover.

	= 1.4 =
	* 05/03/2015 add-  Post link to title.
	* 05/03/2015 add-  Post link to thumbnail.


	= 1.3 =
	* 05/03/2015 fix-  pagination at home page issue fixed.


	= 1.2 =
	* 05/03/2015 remove-  removed some options.
	* 05/03/2015 add-  grid layout builder.

	= 1.1 =
    * 03/03/2015 add-  option for display/hide social share buttons.
    * 03/03/2015 remove- Thumbnail width.
    * 03/03/2015 add- Masonry grid enable for any theme.
    * 03/03/2015 remove- Masonry grid theme.

	= 1.0 =
    * 06/02/2015 Initial release.