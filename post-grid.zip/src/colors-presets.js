const colorsPresets = [
  { name: '9DD6DF', color: '#9DD6DF' },
  { name: '18978F', color: '#18978F' },
  { name: 'A084CF', color: '#A084CF' },
  { name: 'DFBB9D', color: '#DFBB9D' },
  { name: '774360', color: '#774360' },
  { name: '3AB0FF', color: '#3AB0FF' },
  { name: '51557E', color: '#51557E' },
];


export default colorsPresets;